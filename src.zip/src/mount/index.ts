import {mountCreep} from "@/mount/creep/creep";
import {mountRoom} from "@/mount/room/room";

mountCreep()
mountRoom()