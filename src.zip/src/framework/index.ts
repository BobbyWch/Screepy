//所有需要初始化的在这里import
import "@/obj/index"




